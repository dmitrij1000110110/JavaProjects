package expression;

import expression.exceptions.ExpressionException;

public interface TripleExpression<T> {
    public T evaluate(int x, int y, int z) throws ExpressionException;
}
