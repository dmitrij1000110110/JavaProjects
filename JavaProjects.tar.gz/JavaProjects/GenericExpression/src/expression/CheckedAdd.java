package expression;

import expression.calculators.Calculator;
import expression.exceptions.ExpressionException;
import expression.exceptions.OverflowException;

public class CheckedAdd<T> extends AbstractCheckedBinaryOperator<T>{

    public CheckedAdd(TripleExpression<T> left, TripleExpression<T> right, Calculator<T> calculator) {
        super(left, right, calculator);
    }

    @Override
    protected T getResult(T left, T right) throws ExpressionException {
        if (calculator.hasMaxAndMinValue() && (calculator.more(right, calculator.zero()) && calculator.less(calculator.subtract(calculator.maxValue(), right), left) || (calculator.less(right, calculator.zero()) && calculator.more(calculator.subtract(calculator.minValue(), right), left)))) {
            throw new OverflowException("Add", left + " + " + right);
        }
        return calculator.add(left, right);
    }
}
