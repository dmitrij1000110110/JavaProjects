package expression.parser;

import expression.exceptions.IncorrectExpressionException;

public class Tokenizer {
    private String in;
    private int pos = 0;
    private static final String[] search = {"+", "-", "*", "/", "(", ")", "abs", "square", "mod"};
    private static final Token[] token = {
            Token.ADD, Token.SUB,
            Token.MUL, Token.DIV, Token.OPEN_BRACKET, Token.CLOSE_BRACKET, Token.ABS, Token.SQUARE, Token.MOD
    };
    private static final int N = token.length;
    private String lastToken;

    Tokenizer(String source) {
        this.in = source;
    }

    private boolean check(char c) {
        if (in.charAt(pos) == c) {
            pos++;
            return true;
        }
        return false;
    }

    private void skipBlanks() {
        while (pos < in.length()
                && (check(' ') || check('\t') || check('\n') || check('\r'))) {
        }
    }

    private String getNumber() {
        StringBuilder res = new StringBuilder();
        while (pos < in.length() && Character.isDigit(in.charAt(pos))) {
            res.append(in.charAt(pos++));
        }
        return lastToken = res.toString();
    }

    private boolean isVariableName() {
        return check('x') || check('y') || check('z');
    }

    Token nextToken() throws IncorrectExpressionException {
        skipBlanks();
        if (pos >= in.length()) {
            //System.out.println(Token.END);
            return Token.END;
        }
        if (Character.isDigit(in.charAt(pos))) {
            getNumber();
            //System.out.println(Token.CONST);
            return Token.CONST;
        }
        for (int i = 0; i < N; i++) {
            if (in.startsWith(search[i], pos)) {
                lastToken = in.substring(pos, pos + search[i].length());
                pos += search[i].length();
                //System.out.println(token[i]);
                return token[i];
            }
        }
        if (isVariableName()) {
            lastToken = Character.toString(in.charAt(pos - 1));
            //System.out.println(Token.VAR);
            return Token.VAR;
        }
        if (pos == in.length()) {
            //System.out.println(Token.END);
            return Token.END;
        }
        throw new IncorrectExpressionException();
    }

    String getLastToken() {
        return lastToken;
    }
}
