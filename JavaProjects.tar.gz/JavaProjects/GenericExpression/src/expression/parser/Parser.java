package expression.parser;

import expression.TripleExpression;
import expression.calculators.Calculator;
import expression.exceptions.IncorrectExpressionException;

public interface Parser {
    public TripleExpression parse(String expression, Calculator calculator) throws IncorrectExpressionException;
}
