package expression.parser;

import expression.*;
import expression.calculators.Calculator;
import expression.exceptions.IncorrectExpressionException;

public class ExpressionParser implements Parser {
    private Token curToken;
    private Tokenizer tokenizer;

    private void getNextToken() throws IncorrectExpressionException {
        curToken = tokenizer.nextToken();
    }

    private TripleExpression parseHighestPriority(Calculator calculator) throws IncorrectExpressionException {
        TripleExpression res;
        switch (curToken) {
            case CONST:
                res = new Const(calculator.valueOf(tokenizer.getLastToken()));
                getNextToken();
                return res;
            case OPEN_BRACKET:
                getNextToken();
                res = parseAddAndSub(calculator);
                if (curToken != Token.CLOSE_BRACKET) {
                    throw new IllegalStateException("Close bracket error.");
                }
                getNextToken();
                return res;
            case VAR:
                res = new Variable(tokenizer.getLastToken(), calculator);
                getNextToken();
                return res;
            case SUB:
                getNextToken();
                if (curToken == Token.CONST) {
                    res = new Const(calculator.valueOf("-" + tokenizer.getLastToken()));
                    getNextToken();
                    return res;
                } else {
                    return new CheckedNegate(parseHighestPriority(calculator), calculator);
                }
            case ABS:
                getNextToken();
                if (curToken == Token.CONST) {
                    res = new Const(calculator.abs(calculator.valueOf(tokenizer.getLastToken())));
                    getNextToken();
                    return res;
                } else {
                    return new Abs(parseHighestPriority(calculator), calculator);
                }
            case SQUARE:
                getNextToken();
                if (curToken == Token.CONST) {
                    res = new Const(calculator.square(calculator.valueOf(tokenizer.getLastToken())));
                    getNextToken();
                    return res;
                } else {
                    return new Square(parseHighestPriority(calculator), calculator);
                }
        }
        throw new IllegalStateException("Wrong operator: " + tokenizer.getLastToken());
    }

    private TripleExpression parseMulDivMod(Calculator calculator) throws IncorrectExpressionException {
        TripleExpression res = parseHighestPriority(calculator);
        while (curToken != Token.END) {
            if (curToken == Token.MUL) {
                getNextToken();
                res = new CheckedMultiply(res, parseHighestPriority(calculator), calculator);
            } else if (curToken == Token.DIV) {
                getNextToken();
                res = new CheckedDivide(res, parseHighestPriority(calculator), calculator);
            } else if (curToken == Token.MOD){
                getNextToken();
                res = new Mod(res, parseHighestPriority(calculator), calculator);
            } else {
                break;
            }
        }
        return res;
    }

    private TripleExpression parseAddAndSub(Calculator calculator) throws IncorrectExpressionException {
        TripleExpression res = parseMulDivMod(calculator);
        while (curToken != Token.END) {
            if (curToken == Token.ADD) {
                getNextToken();
                res = new CheckedAdd(res, parseMulDivMod(calculator), calculator);
            } else if (curToken == Token.SUB) {
                getNextToken();
                res = new CheckedSubtract(res, parseMulDivMod(calculator), calculator);
            } else {
                break;
            }
        }
        return res;
    }

    @Override
    public TripleExpression parse(String expression, Calculator calculator) throws IncorrectExpressionException {
        tokenizer = new Tokenizer(expression);
        getNextToken();
        TripleExpression res = parseAddAndSub(calculator);
        if (curToken != Token.END) {
            throw new IncorrectExpressionException();
        }
        return res;
    }
}
