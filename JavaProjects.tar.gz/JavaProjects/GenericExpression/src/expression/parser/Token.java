package expression.parser;

enum Token {
   ADD, SUB, MUL, DIV, VAR, CONST, OPEN_BRACKET, CLOSE_BRACKET, END, ABS, SQUARE, MOD
}
