package expression;

import expression.calculators.Calculator;
import expression.exceptions.ExpressionException;

public class Abs<T> extends AbstractCheckedUnoOperator<T> {

    public Abs(TripleExpression<T> in, Calculator<T> calculator) {
        super(in, calculator);
    }

    @Override
    protected T getResult(T in) throws ExpressionException {
        return calculator.abs(in);
    }
}
