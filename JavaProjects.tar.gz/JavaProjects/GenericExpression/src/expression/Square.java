package expression;

import expression.calculators.Calculator;
import expression.exceptions.ExpressionException;
import expression.exceptions.OverflowException;

public class Square<T> extends AbstractCheckedUnoOperator<T> {

    public Square(TripleExpression<T> in, Calculator<T> calculator) {
        super(in, calculator);
    }

    @Override
    protected T getResult(T in) throws ExpressionException {
        T res = calculator.multiply(in, in);
        if (calculator.hasMaxAndMinValue() && in != calculator.zero()) {
            if (calculator.divide(res, in) != in) {
                throw new OverflowException("square ", calculator.toString(in));
            }
        }
        return res;
    }
}
