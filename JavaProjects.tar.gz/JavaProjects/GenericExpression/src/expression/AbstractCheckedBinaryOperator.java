package expression;

import expression.calculators.Calculator;
import expression.exceptions.ExpressionException;

public abstract class AbstractCheckedBinaryOperator<T> implements TripleExpression<T> {

    protected final TripleExpression<T> left, right;
    protected final Calculator<T> calculator;

    public AbstractCheckedBinaryOperator(TripleExpression left, TripleExpression right, Calculator calculator) {
        this.left = left;
        this.right = right;
        this.calculator = calculator;
    }

    protected abstract T getResult(T left, T right) throws ExpressionException;

    @Override
    final public T evaluate(int x, int y, int z) throws ExpressionException {
        return getResult(left.evaluate(x, y, z), right.evaluate(x, y, z));
    }

}
