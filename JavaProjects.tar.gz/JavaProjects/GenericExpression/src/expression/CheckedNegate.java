package expression;

import expression.calculators.Calculator;
import expression.exceptions.ExpressionException;
import expression.exceptions.OverflowException;

public class CheckedNegate<T> extends AbstractCheckedUnoOperator<T> {

    public CheckedNegate(TripleExpression<T> in, Calculator<T> calculator) {
        super(in, calculator);
    }

    @Override
    protected T getResult(T in) throws ExpressionException {
        if (calculator.hasMaxAndMinValue() && calculator.equals(in, calculator.minValue())) {
            throw new OverflowException("Negate", calculator.toString(in));
        }
        return calculator.negate(in);
    }
}
