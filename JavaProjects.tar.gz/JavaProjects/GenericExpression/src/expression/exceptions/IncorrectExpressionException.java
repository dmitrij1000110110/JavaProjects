package expression.exceptions;

public class IncorrectExpressionException extends ExpressionException {
    public IncorrectExpressionException() {
        super("Incorrect expression");
    }
}
