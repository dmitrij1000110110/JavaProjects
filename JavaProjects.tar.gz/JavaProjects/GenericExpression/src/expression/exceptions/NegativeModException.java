package expression.exceptions;

public class NegativeModException extends ExpressionException {
    public NegativeModException(String x, String y) {
        super(x + " mod " + y);
    }
}
