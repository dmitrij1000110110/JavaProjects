package expression.exceptions;

public class DivisionByZeroException extends ExpressionException{

    public DivisionByZeroException(String in) {
        super("Division " + in + " by 0");
    }
}
