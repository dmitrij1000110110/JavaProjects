package expression.exceptions;

public class IncorrectVariableNameException extends ExpressionException {
    public IncorrectVariableNameException(String name) {
        super("Incorrect variable name " + name);
    }
}
