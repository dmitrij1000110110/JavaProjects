package expression.exceptions;

public class OverflowException extends ExpressionException {
    public OverflowException(String operatorName, String input) {
        super(operatorName + " overflowed by " + input);
    }
}