package expression.generic;

import expression.TripleExpression;
import expression.calculators.*;
import expression.exceptions.ExpressionException;
import expression.parser.ExpressionParser;

import java.math.BigInteger;

public class GenericTabulator implements Tabulator {

    @Override
    public Object[][][] tabulate(String mode, String expression, int x1, int x2, int y1, int y2, int z1, int z2) throws Exception {
        Calculator calculator = switch (mode) {
            case "i" -> new IntCalculator();
            case "d" -> new DoubleCalculator();
            case "bi" -> new BigIntegerCalculator();
            case "u" -> new UIntCalculator();
            case "p" -> new PIntCalculator();
            case "b" -> new ByteCalculator();
            default -> throw new IllegalStateException("Unexpected value: " + mode);
        };
        TripleExpression expr = new ExpressionParser().parse(expression, calculator);
        int nx = x2 - x1 + 1;
        int ny = y2 - y1 + 1;
        int nz = z2 - z1 + 1;
        Object[][][] res = new Object[nx][ny][nz];
        for (int ix = 0; ix < nx; ix++) {
            for (int iy = 0; iy < ny; iy++) {
                for (int iz = 0; iz < nz; iz++) {
                    int x0 = x1 + ix;
                    int y0 = y1 + iy;
                    int z0 = z1 + iz;
                    try {
                        res[ix][iy][iz] = expr.evaluate(x0, y0, z0);
                    } catch (ExpressionException e) {

                    }
                }
            }
        }
        return res;
    }

}
