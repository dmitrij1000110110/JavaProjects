package expression;

import expression.calculators.Calculator;
import expression.exceptions.DivisionByZeroException;
import expression.exceptions.ExpressionException;
import expression.exceptions.NegativeModException;

public class Mod<T> extends AbstractCheckedBinaryOperator<T> {

    public Mod(TripleExpression left, TripleExpression right, Calculator calculator) {
        super(left, right, calculator);
    }

    @Override
    protected T getResult(T left, T right) throws ExpressionException {
        if (!calculator.negativeModAllowed() && calculator.less(right, calculator.zero())) {
            throw new NegativeModException(calculator.toString(left), calculator.toString(right));
        }
        if (!calculator.zeroDivisionAllowed() && calculator.equals(right, calculator.zero())) {
            throw new DivisionByZeroException(left + " mod " + right);
        }
        return calculator.mod(left, right);
    }
}
