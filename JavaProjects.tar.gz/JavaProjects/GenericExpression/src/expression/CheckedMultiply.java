package expression;

import expression.calculators.Calculator;
import expression.exceptions.ExpressionException;
import expression.exceptions.OverflowException;

public class CheckedMultiply<T> extends AbstractCheckedBinaryOperator<T> {

    public CheckedMultiply(TripleExpression<T> left, TripleExpression<T> right, Calculator<T> calculator) {
        super(left, right, calculator);
    }

    @Override
    protected T getResult(T left, T right) throws ExpressionException {
        T res = calculator.multiply(left, right);
        if (calculator.hasMaxAndMinValue() && !calculator.equals(right, calculator.zero())) {
            if (!calculator.equals(left, calculator.divide(res, right))) {
                throw new OverflowException("Multiply", left + " * " + right);
            }
        }
        return res;
    }
}
