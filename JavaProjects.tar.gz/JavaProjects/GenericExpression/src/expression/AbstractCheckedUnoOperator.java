package expression;

import expression.calculators.Calculator;
import expression.exceptions.ExpressionException;

abstract class AbstractCheckedUnoOperator<T> implements TripleExpression<T> {
    protected final TripleExpression<T> in;
    protected final Calculator<T> calculator;

    public AbstractCheckedUnoOperator(TripleExpression<T> in, Calculator<T> calculator) {
        this.in = in;
        this.calculator = calculator;
    }

    protected abstract T getResult(T in) throws ExpressionException;

    @Override
    final public T evaluate(int x, int y, int z) throws ExpressionException {
        return getResult(in.evaluate(x, y, z));
    }
}
