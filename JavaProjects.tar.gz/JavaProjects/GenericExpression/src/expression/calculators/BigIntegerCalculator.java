package expression.calculators;

import java.math.BigInteger;

public class BigIntegerCalculator extends AbstractCalculator<BigInteger> {
    @Override
    public BigInteger add(BigInteger x, BigInteger y) {
        return x.add(y);
    }

    @Override
    public BigInteger subtract(BigInteger x, BigInteger y) {
        return x.subtract(y);
    }

    @Override
    public BigInteger multiply(BigInteger x, BigInteger y) {
        return x.multiply(y);
    }

    @Override
    public BigInteger divide(BigInteger x, BigInteger y) {
        return x.divide(y);
    }

    @Override
    public BigInteger mod(BigInteger x, BigInteger y) {
        return x.mod(y);
    }

    @Override
    public BigInteger zero() {
        return BigInteger.ZERO;
    }

    @Override
    public boolean more(BigInteger x, BigInteger y) {
        return x.compareTo(y) > 0;
    }

    @Override
    public boolean less(BigInteger x, BigInteger y) {
        return x.compareTo(y) < 0;
    }

    @Override
    public boolean hasMaxAndMinValue() {
        return false;
    }

    @Override
    public boolean zeroDivisionAllowed() {
        return false;
    }

    @Override
    public boolean negativeModAllowed() {
        return false;
    }

    @Override
    public boolean equals(BigInteger x, BigInteger y) {
        return x.equals(y);
    }

    @Override
    public BigInteger maxValue() {
        return null;
    }

    @Override
    public BigInteger minValue() {
        return null;
    }

    @Override
    public BigInteger minusOne() {
        return BigInteger.ZERO.subtract(BigInteger.ONE);
    }

    @Override
    public BigInteger abs(BigInteger x) {
        if (x.compareTo(BigInteger.ZERO) < 0) {
            return negate(x);
        }
        return x;
    }

    @Override
    public BigInteger negate(BigInteger x) {
        return BigInteger.ZERO.subtract(x);
    }

    @Override
    public String toString(BigInteger x) {
        return x.toString();
    }

    @Override
    public BigInteger valueOf(String x) {
        return new BigInteger(x);
    }

    @Override
    public BigInteger valueOf(int x) {
        return valueOf(Integer.toString(x));
    }
}
