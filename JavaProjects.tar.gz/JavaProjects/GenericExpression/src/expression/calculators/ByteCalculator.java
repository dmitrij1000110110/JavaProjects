package expression.calculators;

public class ByteCalculator extends AbstractCalculator<Byte>{

    @Override
    public Byte add(Byte x, Byte y) {
        return (byte) (x + y);
    }

    @Override
    public Byte subtract(Byte x, Byte y) {
        return (byte) (x - y);
    }

    @Override
    public Byte multiply(Byte x, Byte y) {
        return (byte) (x * y);
    }

    @Override
    public Byte divide(Byte x, Byte y) {
        return (byte) (x / y);
    }

    @Override
    public Byte mod(Byte x, Byte y) {
        return (byte) (x % y);
    }

    @Override
    public Byte zero() {
        return 0;
    }

    @Override
    public boolean more(Byte x, Byte y) {
        return x > y;
    }

    @Override
    public boolean less(Byte x, Byte y) {
        return x < y;
    }

    @Override
    public boolean hasMaxAndMinValue() {
        return false;
    }

    @Override
    public boolean zeroDivisionAllowed() {
        return false;
    }

    @Override
    public boolean equals(Byte x, Byte y) {
        return x.equals(y);
    }

    @Override
    public Byte maxValue() {
        return null;
    }

    @Override
    public Byte minValue() {
        return null;
    }

    @Override
    public Byte minusOne() {
        return -1;
    }

    @Override
    public Byte abs(Byte x) {
        return (byte) Math.abs(x);
    }

    @Override
    public Byte negate(Byte x) {
        return (byte) -x;
    }

    @Override
    public String toString(Byte x) {
        return Byte.toString(x);
    }

    @Override
    public Byte valueOf(String x) {
        return Byte.parseByte(x);
    }

    @Override
    public Byte valueOf(int x) {
        return (byte) x;
    }
}
