package expression.calculators;

public class PIntCalculator extends IntCalculator {

    private static final int MOD = 1009;

    @Override
    public Integer add(Integer x, Integer y) {
        return (x + y) % MOD;
    }

    @Override
    public Integer subtract(Integer x, Integer y) {
        return ((x - y) % MOD + MOD) % MOD;
    }

    @Override
    public Integer multiply(Integer x, Integer y) {
        return (x * y) % MOD;
    }

    private static int powmod(int x, int p) {
        if (p == 0) {
            return 1;
        }
        if (p % 2 == 0) {
            int y = powmod(x, p / 2);
            return (y * y) % MOD;
        }
        return (x * powmod(x, p - 1)) % MOD;
    }

    @Override
    public Integer divide(Integer x, Integer y) {
        return (x * powmod(y, MOD - 2)) % MOD;
    }

    @Override
    public boolean hasMaxAndMinValue() {
        return false;
    }

    @Override
    public Integer valueOf(String x) {
        return (Integer.parseInt(x) % MOD + MOD) % MOD;
    }

    @Override
    public Integer valueOf(int x) {
        return (x % MOD + MOD) % MOD;
    }
}
