package expression.calculators;

public class UIntCalculator extends IntCalculator {

    @Override
    public boolean hasMaxAndMinValue() {
        return false;
    }

}
