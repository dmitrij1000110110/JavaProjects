package expression.calculators;

public abstract class AbstractCalculator<T> implements Calculator<T> {

    @Override
    public abstract T add(T x, T y);

    @Override
    public abstract T subtract(T x, T y);

    @Override
    public abstract T multiply(T x, T y);

    @Override
    public T square(T x) {
        return multiply(x, x);
    }

    @Override
    public abstract T mod(T x, T y);

    @Override
    public abstract T divide(T x, T y);

    @Override
    public abstract T zero();

    @Override
    public abstract boolean more(T x, T y);

    @Override
    public boolean less(T x, T y) {
        return !more(x, y) && !equals(x, y);
    }

    @Override
    public boolean hasMaxAndMinValue() {
        return false;
    }

    @Override
    public boolean zeroDivisionAllowed() {
        return false;
    }

    @Override
    public boolean negativeModAllowed() {
        return true;
    }

    @Override
    public boolean equals(T x, T y) {
        return x.equals(y);
    }

    @Override
    public T maxValue() {
        return null;
    }

    @Override
    public T minValue() {
        return null;
    }

    @Override
    public abstract T minusOne();

    @Override
    public abstract T abs(T x);

    @Override
    public T negate(T x) {
        return subtract(zero(), x);
    }

    @Override
    public abstract String toString(T x);

    @Override
    public abstract T valueOf(String x);

    public abstract T valueOf(int x);
}
