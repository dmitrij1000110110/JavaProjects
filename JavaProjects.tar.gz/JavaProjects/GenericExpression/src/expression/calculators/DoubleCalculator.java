package expression.calculators;

public class DoubleCalculator extends AbstractCalculator<Double> {
    @Override
    public Double add(Double x, Double y) {
        return x + y;
    }

    @Override
    public Double subtract(Double x, Double y) {
        return x - y;
    }

    @Override
    public Double multiply(Double x, Double y) {
        return x * y;
    }

    @Override
    public Double divide(Double x, Double y) {
        return x / y;
    }

    @Override
    public Double mod(Double x, Double y) {
        return x % y;
    }

    @Override
    public Double zero() {
        return 0.;
    }

    @Override
    public boolean more(Double x, Double y) {
        return x > y;
    }

    @Override
    public boolean hasMaxAndMinValue() {
        return false;
    }

    @Override
    public boolean zeroDivisionAllowed() {
        return true;
    }

    @Override
    public Double maxValue() {
        return null;
    }

    @Override
    public Double minValue() {
        return null;
    }

    @Override
    public Double minusOne() {
        return -1.;
    }

    @Override
    public Double abs(Double x) {
        return Math.abs(x);
    }

    @Override
    public String toString(Double x) {
        return Double.toString(x);
    }

    @Override
    public Double valueOf(String x) {
        return Double.parseDouble(x);
    }

    @Override
    public Double valueOf(int x) {
        return (double) x;
    }
}
