package expression.calculators;

public interface Calculator<T> {

    T add(T x, T y);

    T subtract(T x, T y);

    T multiply(T x, T y);

    T square(T x);

    T divide(T x, T y);

    T mod(T x, T y);

    T zero();

    boolean more(T x, T y);

    boolean less(T x, T y);

    boolean hasMaxAndMinValue();

    boolean zeroDivisionAllowed();

    boolean negativeModAllowed();

    boolean equals(T x, T y);

    T maxValue();

    T minValue();

    T minusOne();

    T abs(T x);

    T negate(T x);

    String toString(T x);

    T valueOf(String x);

    T valueOf(int x);
}
