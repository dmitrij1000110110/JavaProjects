package expression;

import expression.calculators.Calculator;

public class Variable<T> implements TripleExpression<T> {
    private final String name;
    private final Calculator<T> calculator;

    public Variable(String name, Calculator<T> calculator) {
        this.name = name;
        this.calculator = calculator;
    }

    @Override
    public T evaluate(int x, int y, int z) {
        switch (name) {
            case "x":
                return calculator.valueOf(x);
            case "y":
                return calculator.valueOf(y);
            case "z":
                return calculator.valueOf(z);
        }
        return null;
    }

}
