package expression;

import expression.calculators.Calculator;
import expression.exceptions.DivisionByZeroException;
import expression.exceptions.ExpressionException;
import expression.exceptions.OverflowException;

public class CheckedDivide<T> extends AbstractCheckedBinaryOperator<T> {

    public CheckedDivide(TripleExpression<T> left, TripleExpression<T> right, Calculator<T> calculator) {
        super(left, right, calculator);
    }

    @Override
    protected T getResult(T left, T right) throws ExpressionException {
        if (!calculator.zeroDivisionAllowed() && calculator.equals(right, calculator.zero())) {
            throw new DivisionByZeroException(calculator.toString(left));
        }
        if (calculator.hasMaxAndMinValue() && calculator.equals(left, calculator.minValue()) && calculator.equals(right, calculator.minusOne())) {
            throw new OverflowException("Divide", left + " / " + right);
        }
        return calculator.divide(left, right);
    }
}
