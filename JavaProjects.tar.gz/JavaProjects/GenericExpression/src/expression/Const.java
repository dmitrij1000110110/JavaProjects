package expression;

public class Const<T> implements TripleExpression<T> {
    private final T val;

    public Const(T val) {
        this.val = val;
    }

    @Override
    public T evaluate(int x, int y, int z) {
        return val;
    }

}
