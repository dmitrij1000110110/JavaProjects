package search;

public class BinarySearchMax {

    //Pred: a is bitonic(first increase then decrease)
    //Post: x: maximum in a
    public static int iterativeBinarySearch(int[] a) {
        //a is bitonic
        int l = 0;
        int r = a.length - 1;
        //a is bitonic, l == 0, r == a.length - 1

        //l <= r, maximum is in [l; r]
        while (l < r) {
            //l < r
            int m = (l + r) / 2;
            //l <= m < r
            if (a[m] > a[m + 1]) {
                //a[m] > a[m + 1] => maximum is in [l; m]
                r = m;
                //maximum is in [l; r]
            } else {
                //a[m] < a[m + 1] => maximum is in [m + 1; r]
                l = m + 1;
                //maximum is in [l; r]
            }
            //maximum is in [l; r]
        }
        //maximum is in [l; r], l == r => a[l] is maximum
        return a[l];
    }

    //Pred: a is bitonic(first increase then decrease), maximum is in [l; r]
    //Post: x: maximum in a
    public static int recursiveBinarySearch(int[] a, int l, int r) {
        if (l == r) {
            //l == r, maximum is in [l; r] => a[l] is maximum
            return a[l];
            //a[l] == maximum in a
        }
        //l < r, maximum is in [l; r]
        int m = (l + r) / 2;
        //l <= m < r
        if (a[m] > a[m + 1]) {
            //a[m] > a[m + 1] => maximum is in [l; m]
            return recursiveBinarySearch(a, l, m);
            //maximum in [l; m] == maximum in [l; r]
        }
        //a[m] < a[m + 1] => maximum is in [m + 1; r]
        return recursiveBinarySearch(a, m + 1, r);
        //maximum in [m + 1; r] == maximum in [l; r]
    }

    //Pred: at least one arg, all args are ints, args are bitonic(first increase then decrease)
    //Post: i: a[i] <= x, for all j < i a[j] > x
    public static void main(String[] args) {
        int[] a = new int[args.length];
        for (int i = 0; i < args.length; i++) {
            a[i] = Integer.parseInt(args[i]);
        }
        System.out.println(iterativeBinarySearch(a));
    }

}
