package queue;

import java.util.Arrays;

public class ArrayQueueModule {

    // Model:
    // [a1, a2, ..., an]
    // n - число элементов в очереди
    // Invariant:
    // n >= 0
    // forall i in [1..n] a[i] != null

    // Immutable: n = n' && forall i in [1..n] a[i] == a'[i]

    private static int begin = 0, size = 0;
    public static Object[] elements = new Object[2];

    private static void ensureCapacity() {
        if (size == elements.length) {
            elements = Arrays.copyOf(elements, elements.length * 2);
            System.arraycopy(elements, 0, elements, elements.length / 2, begin);
            if (begin > 0) {
                Arrays.fill(elements, 0, begin - 1, null);
            }
        }
    }

    // Pred: element != null
    // Post: n == n' + 1 && a[n] == element && forall i in [1..n'] a[i] == a'[i]
    public static void enqueue(Object element) {
        ensureCapacity();
        elements[(begin + size) % elements.length] = element;
        size++;
    }

    // Pred: n > 0
    // Post: R == a[1] && Immutable
    public static Object element() {
        return elements[begin];
    }

    //Pred: n > 0
    //Post: n == n' - 1 && R = a'[1] && forall i in [1..n] a[i] == a'[i + 1]
    public static Object dequeue() {
        Object res = elements[begin];
        elements[begin] = null;
        begin = (begin + 1) % elements.length;
        size--;
        return res;
    }

    //Pred: true
    //Post: R == n && Immutable
    public static int size() {
        return size;
    }

    //Pred: true
    //Post: R == (n == 0) && Immutable
    public static boolean isEmpty() {
        return size == 0;
    }

    //Pred: true
    //Post: n == 0
    public static void clear() {
        while (!isEmpty()) {
            dequeue();
        }
        begin = size = 0;
    }

    //Pred: element != null
    //Post: n == n' + 1 && a[1] = element && forall i in [1..n'] a[i + 1] == a'[i]
    public static void push(Object element) throws Exception {
        ensureCapacity();
        size++;
        begin = (begin + elements.length - 1) % elements.length;
        elements[begin] = element;
    }

    //Pred: size > 0
    //Post: R == a[n] && Immutable
    public static Object peek() {
        return elements[(begin + size - 1) % elements.length];
    }

    //Pred: size > 0
    //Post: R == elements[n] && n == n' - 1 && forall i in [1..n] a[i] = a'[i]
    public static Object remove() {
        int i = (begin + size - 1) % elements.length;
        Object res = elements[i];
        elements[i] = null;
        size--;
        return res;
    }

    //Pred: true
    //Post: R = [a[1], a[2], ..., a[n]]
    public static Object[] toArray() {
        Object[] res = new Object[size];
        if (size == 0 || begin + size - 1 < elements.length) {
            System.arraycopy(elements, begin, res, 0, size);
        } else {
            System.arraycopy(elements, begin, res, 0, elements.length - begin);
            System.arraycopy(elements, 0, res, elements.length - begin, size - elements.length + begin);
        }
        return res;
    }

    //Pred: true
    //Post: R = string value in format [ a[1], ... , a[n] ]
    public static String toStr() {
        Object[] arr = toArray();
        return Arrays.toString(arr);
    }

}
