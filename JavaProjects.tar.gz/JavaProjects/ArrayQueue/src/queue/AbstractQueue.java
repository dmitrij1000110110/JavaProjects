package queue;

import java.util.List;
import java.util.function.Function;

public abstract class AbstractQueue implements Queue {

    protected int size;

    @Override
    public abstract void enqueue(Object element);

    public abstract void removeElement();

    @Override
    public Object dequeue() {
        Object result = element();
        size--;
        removeElement();
        return result;
    }

    @Override
    public abstract Object element();

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public void clear() {
        while (!isEmpty()) {
            dequeue();
        }
    }

    @Override
    public abstract Object[] toArray();

    public abstract Queue getInstance();

    public Queue nth(int n, boolean returnQueue, boolean remove) {
        int sz = size();
        Queue res = getInstance();
        for (int i = 0; i < sz; i++) {
            Object elem = element();
            if ((i + 1) % n == 0 && returnQueue) {
                res.enqueue(elem);
            }
            dequeue();
            if ((i + 1) % n > 0 || !remove) {
                enqueue(elem);
            }
        }
        return res;
    }

    @Override
    public Queue removeNth(int n) {
        return nth(n, true, true);
    }

    @Override
    public Queue getNth(int n) {
        return nth(n, true, false);
    }

    @Override
    public void dropNth(int n) {
        nth(n, false, true);
    }
}
