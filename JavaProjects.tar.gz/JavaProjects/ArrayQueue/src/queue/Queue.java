package queue;

import java.util.Arrays;

public interface Queue {

    // Model:
    // [a1, a2, ..., am]
    // m - число элементов в очереди
    // Inv:
    // m >= 0
    // forall i in [1..m] a[i] != null

    // Pred: element != null
    // Post: m == m' + 1 && a[m] == element && forall i in [1..m'] a[i] == a'[i]
    public void enqueue(Object element);

    //Pred: m > 0
    //Post: m == m' - 1 && R = a'[1] && forall i in [1..m] a[i] == a'[i + 1]
    public Object dequeue();

    // Pred: m > 0
    // Post: R == a[1] && Immutable
    public Object element();

    //Pred: true
    //Post: R == m && Immutable
    public int size();

    //Pred: true
    //Post: R == (m == 0) && Immutable
    public boolean isEmpty();

    //Pred: true
    //Post: m == 0
    public void clear();

    //Pred: n > 0
    //Post: [a'[n], a'[2*n], ..., a'[k * n]], k = m/n && Immutable
    public Queue getNth(int n);

    //Pred: n > 0
    //Post: [a'[n], a'[2*n], ..., a'[k * n]], k = m/n && a = [a'[1], ..., a'[n - 1], a'[n + 1], ..., a'[2 * n - 1], a'[2 * n + 1], ...]
    public Queue removeNth(int n);

    //Pred: n > 0
    //Post: k = m/n && a = [a'[1], ..., a'[n - 1], a'[n + 1], ..., a'[2 * n - 1], a'[2 * n + 1], ...]
    public void dropNth(int n);

    //Pred: true
    //Post: R = [a[1], a[2], ..., a[n]]
    public Object[] toArray();
}
