package queue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;

public class ArrayQueue extends AbstractQueue {

    // Model:
    // [a1, a2, ..., an]
    // n - число элементов в очереди
    // Invariant:
    // n >= 0
    // forall i in [1..n] a[i] != null

    // Immutable: n = n' && forall i in [1..n] a[i] == a'[i]

    private int begin = 0;
    public Object[] elements = new Object[2];

    private void ensureCapacity() {
        if (size == elements.length) {
            elements = Arrays.copyOf(elements, elements.length * 2);
            System.arraycopy(elements, 0, elements, elements.length / 2, begin);
            if (begin > 0) {
                Arrays.fill(elements, 0, begin - 1, null);
            }
        }
    }

    // Pred: element != null
    // Post: n == n' + 1 && a[n] == element && forall i in [1..n'] a[i] == a'[i]
    public void enqueue(Object element) {
        ensureCapacity();
        elements[(begin + size) % elements.length] = element;
        size++;
    }

    @Override
    public void removeElement() {
        elements[begin] = null;
        begin = (begin + 1) % elements.length;
    }

    // Pred: n > 0
    // Post: R == a[1] && Immutable
    public Object element() {
        return elements[begin];
    }

    //Pred: true
    //Post: R == n && Immutable
    public int size() {
        return size;
    }

    //Pred: true
    //Post: R == (n == 0) && Immutable
    public boolean isEmpty() {
        return size == 0;
    }

    //Pred: true
    //Post: n == 0
    public void clear() {
        while (!isEmpty()) {
            dequeue();
        }
        begin = size = 0;
    }

    //Pred: element != null
    //Post: n == n' + 1 && a[1] = element && forall i in [1..n'] a[i + 1] == a'[i]
    public void push(Object element) {
        ensureCapacity();
        size++;
        begin = (begin + elements.length - 1) % elements.length;
        elements[begin] = element;
    }

    //Pred: size > 0
    //Post: R == a[n] && Immutable
    public Object peek() {
        return elements[(begin + size - 1) % elements.length];
    }

    //Pred: size > 0
    //Post: R == elements[n] && n == n' - 1 && forall i in [1..n] a[i] = a'[i]
    public Object remove() {
        int i = (begin + size - 1) % elements.length;
        Object res = elements[i];
        elements[i] = null;
        size--;
        return res;
    }

    //Pred: true
    //Post: R = [a[1], a[2], ..., a[n]]
    public Object[] toArray() {
        Object[] res = new Object[size];
        if (size == 0 || begin + size - 1 < elements.length) {
            System.arraycopy(elements, begin, res, 0, size);
        } else {
            System.arraycopy(elements, begin, res, 0, elements.length - begin);
            System.arraycopy(elements, 0, res, elements.length - begin, size - elements.length + begin);
        }
        return res;
    }

    //Pred: true
    //Post: R = string value in format [ a[1], ... , a[n] ]
    public String toStr() {
        Object[] arr = toArray();
        return Arrays.toString(arr);
    }

    protected List<Object> get(int n, Function<Pair<Integer, Integer>, Boolean> f) {
        List<Object> res = new ArrayList<>();
        for (int i = 1; i <= size; i++) {
            if (f.apply(new Pair(i, n))) {
                res.add(elements[(begin + i - 1) % elements.length]);
            }
        }
        return res;
    }

    @Override
    public Queue getInstance() {
        return new ArrayQueue();
    }
}
