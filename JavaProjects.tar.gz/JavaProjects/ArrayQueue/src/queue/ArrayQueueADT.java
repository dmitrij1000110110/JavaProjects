package queue;

import java.util.Arrays;

public class ArrayQueueADT {

    // Model:
    // [a1, a2, ..., an]
    // n - число элементов в очереди
    // Invariant:
    // n >= 0
    // forall i in [1..n] a[i] != null

    // Immutable: n = n' && forall i in [1..n] a[i] == a'[i]

    private int begin = 0, size = 0;
    public Object[] elements = new Object[2];

    private static void ensureCapacity(ArrayQueueADT queue) {
        if (queue.size == queue.elements.length) {
            queue.elements = Arrays.copyOf(queue.elements, queue.elements.length * 2);
            System.arraycopy(queue.elements, 0, queue.elements, queue.elements.length / 2, queue.begin);
            if (queue.begin > 0) {
                Arrays.fill(queue.elements, 0, queue.begin - 1, null);
            }
        }
    }

    // Pred: queue != null && element != null
    // Post: n == n' + 1 && a[n] == element && forall i in [1..n'] a[i] == a'[i]
    public static void enqueue(ArrayQueueADT queue, Object element) {
        ensureCapacity(queue);
        queue.elements[(queue.begin + queue.size) % queue.elements.length] = element;
        queue.size++;
    }

    // Pred: queue != null && n > 0
    // Post: R == a[1] && Immutable
    public static Object element(ArrayQueueADT queue) {
        return queue.elements[queue.begin];
    }

    //Pred: queue != null && n > 0
    //Post: n == n' - 1 && R = a'[1] && forall i in [1..n] a[i] == a'[i + 1]
    public static Object dequeue(ArrayQueueADT queue) {
        Object res = queue.elements[queue.begin];
        queue.elements[queue.begin] = null;
        queue.begin = (queue.begin + 1) % queue.elements.length;
        queue.size--;
        return res;
    }

    //Pred: queue != null
    //Post: R == n && Immutable
    public static int size(ArrayQueueADT queue) {
        return queue.size;
    }

    //Pred: queue != null
    //Post: R == (n == 0) && Immutable
    public static boolean isEmpty(ArrayQueueADT queue) {
        return queue.size == 0;
    }

    //Pred: queue != null
    //Post: n == 0
    public static void clear(ArrayQueueADT queue) {
        while (!isEmpty(queue)) {
            dequeue(queue);
        }
        queue.begin = queue.size = 0;
    }

    //Pred: queue != null && element != null
    //Post: n == n' + 1 && a[1] = element && forall i in [1..n'] a[i + 1] == a'[i]
    public static void push(ArrayQueueADT queue, Object element) throws Exception {
        ensureCapacity(queue);
        queue.size++;
        queue.begin = (queue.begin + queue.elements.length - 1) % queue.elements.length;
        queue.elements[queue.begin] = element;
    }

    //Pred: queue != null && size > 0
    //Post: R == a[n] && Immutable
    public static Object peek(ArrayQueueADT queue) {
        return queue.elements[(queue.begin + queue.size - 1) % queue.elements.length];
    }

    //Pred: queue != null && size > 0
    //Post: R == elements[n] && n == n' - 1 && forall i in [1..n] a[i] = a'[i]
    public static Object remove(ArrayQueueADT queue) {
        int i = (queue.begin + queue.size - 1) % queue.elements.length;
        Object res = queue.elements[i];
        queue.elements[i] = null;
        queue.size--;
        return res;
    }

    //Pred: queue != null
    //Post: R = [a[1], a[2], ..., a[n]]
    public static Object[] toArray(ArrayQueueADT queue) {
        Object[] res = new Object[queue.size];
        if (queue.size == 0 || queue.begin + queue.size - 1 < queue.elements.length) {
            System.arraycopy(queue.elements, queue.begin, res, 0, queue.size);
        } else {
            System.arraycopy(queue.elements, queue.begin, res, 0, queue.elements.length - queue.begin);
            System.arraycopy(queue.elements, 0, res, queue.elements.length - queue.begin,
                    queue.size - queue.elements.length + queue.begin);
        }
        return res;
    }

    //Pred: queue != null
    //Post: R = string value in format [ a[1], ... , a[n] ]
    public static String toStr(ArrayQueueADT queue) {
        Object[] arr = toArray(queue);
        return Arrays.toString(arr);
    }

}
