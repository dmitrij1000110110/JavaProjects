package tests;

/**
 * @author Georgiy Korneev (kgeorgiy@kgeorgiy.info)
 */
public class QueueToArrayTest {
    public static void main(final String[] args) {
        QueueTest.testQueue(
                tests.ArrayQueueToArrayTest.Model.class,
                (ArrayQueueToArrayTest.Tester<ArrayQueueToArrayTest.Model>) d -> () -> d
        );
    }
}
