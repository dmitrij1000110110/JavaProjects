import queue.ArrayQueue;
import queue.ArrayQueueADT;
import queue.ArrayQueueModule;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Random;

public class Test {

    public static void WA() {
        System.out.println("Wrong answer");
        System.exit(1);
    }

    private static final int N = 50;

    public static void main(String[] args) throws Exception {
        ArrayQueue arrayQueue = new ArrayQueue();
        ArrayQueueADT arrayQueueADT = new ArrayQueueADT();
        ArrayDeque<Integer> deque = new ArrayDeque<>();
        Random random = new Random();
        int num = 0;
        for (int i = 0; i < 1000000; i++) {
            int x = random.nextInt(N);
            switch (x) {
                case 0 -> {
                    // System.out.println("dequeue");
                    if (num == 0) {
                        continue;
                    }
                    num--;
                    int res = deque.pop();
                    if (res != (int) ArrayQueueModule.dequeue()) {
                        WA();
                    }
                    if (res != (int) arrayQueue.dequeue()) {
                        WA();
                    }
                    if (res != (int) ArrayQueueADT.dequeue(arrayQueueADT)) {
                        WA();
                    }
                }
                case 1 -> {
                    // System.out.println("element");
                    if (num == 0) {
                        continue;
                    }
                    int res = deque.peek();
                    if (res != (int) ArrayQueueModule.element()) {
                        WA();
                    }
                    if (res != (int) arrayQueue.element()) {
                        WA();
                    }
                    if (res != (int) ArrayQueueADT.element(arrayQueueADT)) {
                        WA();
                    }
                }
                case 2 -> {
                    // System.out.println("clear");
                    num = 0;
                    deque.clear();
                    arrayQueue.clear();
                    ArrayQueueModule.clear();
                    ArrayQueueADT.clear(arrayQueueADT);
                }
                case 3 -> {
                    // System.out.println("size");
                    int res = deque.size();
                    if (res != ArrayQueueModule.size()) {
                        WA();
                    }
                    if (res != arrayQueue.size()) {
                        WA();
                    }
                    if (res != ArrayQueueADT.size(arrayQueueADT)) {
                        WA();
                    }
                }
                case 4 -> {
                    // System.out.println("isEmpty");
                    boolean res = deque.isEmpty();
                    if (res != ArrayQueueModule.isEmpty()) {
                        WA();
                    }
                    if (res != arrayQueue.isEmpty()) {
                        WA();
                    }
                    if (res != ArrayQueueADT.isEmpty(arrayQueueADT)) {
                        WA();
                    }
                }
                case 5 -> {
                    // System.out.println("peek");
                    if (num == 0) {
                        continue;
                    }
                    int res = deque.peekLast();
                    if (res != (int) ArrayQueueModule.peek()) {
                        WA();
                    }
                    if (res != (int) arrayQueue.peek()) {
                        WA();
                    }
                    if (res != (int) ArrayQueueADT.peek(arrayQueueADT)) {
                        WA();
                    }
                }
                case 6 -> {
                    // System.out.println("remove");
                    if (num == 0) {
                        continue;
                    }
                    num--;
                    int res = deque.pollLast();
                    if (res != (int) ArrayQueueModule.remove()) {
                        WA();
                    }
                    if (res != (int) arrayQueue.remove()) {
                        WA();
                    }
                    if (res != (int) ArrayQueueADT.remove(arrayQueueADT)) {
                        WA();
                    }
                }
                case 7 -> {
                    // System.out.println("toArray");
                    Object[] arr = deque.toArray();
                    Object[] arrClass = arrayQueue.toArray();
                    Object[] arrModule = ArrayQueueModule.toArray();
                    Object[] arrADT = ArrayQueueADT.toArray(arrayQueueADT);
                    if (arr.length != arrClass.length) {
                        WA();
                    }
                    if (arr.length != arrModule.length) {
                        WA();
                    }
                    if (arr.length != arrADT.length) {
                        WA();
                    }
                    for (int j = 0; j < arr.length; j++) {
                        if ((int) arr[j] != (int) arrClass[j]) {
                            WA();
                        }
                        if ((int) arr[j] != (int) arrModule[j]) {
                            WA();
                        }
                        if ((int) arr[j] != (int) arrADT[j]) {
                            WA();
                        }
                    }
                }
                case 8 -> {
                    // System.out.println("toStr");
                    String str = deque.toString();
                    String strClass = arrayQueue.toStr();
                    String strModule = ArrayQueueModule.toStr();
                    String strADT = ArrayQueueADT.toStr(arrayQueueADT);
                    if (!str.equals(strClass)) {
                        WA();
                    }
                    if (!str.equals(strModule)) {
                        WA();
                    }
                    if (!str.equals(strADT)) {
                        WA();
                    }
                }
                default -> {
                    if (x < 20) {
                        num++;
                        int newElement = random.nextInt(1000);
                        // System.out.println("enqueue " + newElement);
                        deque.add(newElement);
                        ArrayQueueModule.enqueue(newElement);
                        arrayQueue.enqueue(newElement);
                        ArrayQueueADT.enqueue(arrayQueueADT, newElement);
                    } else {
                        num++;
                        int newElement = random.nextInt(1000);
                        // System.out.println("push " + newElement);
                        deque.push(newElement);
                        ArrayQueueModule.push(newElement);
                        arrayQueue.push(newElement);
                        ArrayQueueADT.push(arrayQueueADT, newElement);
                    }
                }
            }
        }
        System.out.println("OK");
    }
}
