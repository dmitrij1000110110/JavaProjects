package markup;

import java.util.List;

public class Paragraph extends Element implements UniversalMarkable {

    public Paragraph(List<UniversalMarkable> texts) {
        super(texts);
    }

    @Override
    protected String getOpenBBCodeTag() {
        return "";
    }

    @Override
    protected String getCloseBBCodeTag() {
        return "";
    }

    @Override
    protected String getMarkdownTag() {
        return "";
    }
}
