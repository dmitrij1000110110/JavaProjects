package markup;

public interface Markdownable {
    void toMarkdown(StringBuilder builder);
}
