package markup;

import java.util.List;

public class Emphasis extends Element {

    private static final String BBCodeTag = "i";
    private static final String markdownTag = "*";

    public Emphasis(List<UniversalMarkable> texts) {
        super(texts);
    }

    @Override
    protected String getOpenBBCodeTag() {
        return "[" + BBCodeTag + "]";
    }

    @Override
    protected String getCloseBBCodeTag() {
        return "[/" + BBCodeTag + "]";
    }

    @Override
    protected String getMarkdownTag() {
        return markdownTag;
    }
}
