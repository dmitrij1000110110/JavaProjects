package markup;

public interface UniversalMarkable extends Markdownable, BBCodeable {
}
