package markup;

import java.util.List;

public class Strikeout extends Element implements Markdownable, BBCodeable {
    private static final String BBCodeTag = "s";
    private static final String markdownTag = "~";

    public Strikeout(List<UniversalMarkable> texts) {
        super(texts);
    }

    @Override
    protected String getOpenBBCodeTag() {
        return "[" + BBCodeTag + "]";
    }

    @Override
    protected String getCloseBBCodeTag() {
        return "[/" + BBCodeTag + "]";
    }

    @Override
    protected String getMarkdownTag() {
        return markdownTag;
    }
}
