package markup;

import java.util.List;

public class OrderedList extends ListElement {

    public OrderedList(List<ListItem> listItems) {
        super(listItems);
    }

    @Override
    protected String getOpenBBCodeTag() {
        return "[list=1]";
    }

    @Override
    protected String getCloseBBCodeTag() {
        return "[/list]";
    }

    @Override
    protected String getMarkdownTag() {
        throw new UnsupportedOperationException();
    }
}
