package markup;

import java.util.List;

public class UnorderedList extends ListElement {

    private static final String BBCodeTag = "list";

    public UnorderedList(List<ListItem> listItems) {
        super(listItems);
    }

    @Override
    protected String getOpenBBCodeTag() {
        return "[" + BBCodeTag + "]";
    }

    @Override
    protected String getCloseBBCodeTag() {
        return "[/" + BBCodeTag + "]";
    }

    @Override
    protected String getMarkdownTag() {
        throw new UnsupportedOperationException();
    }
}
