package markup;

public interface BBCodeable {
    void toBBCode(StringBuilder stringBuilder);
}
