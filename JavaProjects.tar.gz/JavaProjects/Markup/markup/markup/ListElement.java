package markup;

abstract class ListElement extends Element implements UniversalMarkable {
    public ListElement(java.util.List<ListItem> listItems) {
        super(listItems);
    }
}
