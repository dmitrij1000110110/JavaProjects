package markup;

import java.util.List;

public class ListItem extends Element implements UniversalMarkable {

    public ListItem(List<UniversalMarkable> items) {
        super(items);
    }

    @Override
    protected String getOpenBBCodeTag() {
        return "[*]";
    }

    @Override
    protected String getCloseBBCodeTag() {
        return "";
    }

    @Override
    protected String getMarkdownTag() {
        throw new UnsupportedOperationException();
    }
}
