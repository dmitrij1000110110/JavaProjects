package markup;

import java.util.List;

public class Strong extends Element implements Markdownable, BBCodeable {

    private static final String BBCodeTag = "b";
    private static final String markdownTag = "__";

    public Strong(List<UniversalMarkable> texts) {
        super(texts);
    }

    @Override
    protected String getOpenBBCodeTag() {
        return "[" + BBCodeTag + "]";
    }

    @Override
    protected String getCloseBBCodeTag() {
        return "[/" + BBCodeTag + "]";
    }

    @Override
    protected String getMarkdownTag() {
        return markdownTag;
    }
}
