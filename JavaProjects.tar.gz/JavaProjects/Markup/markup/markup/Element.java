package markup;

import java.util.List;

public abstract class Element implements UniversalMarkable {
    private List<? extends UniversalMarkable> texts;

    public Element(List<? extends UniversalMarkable> texts) {
        this.texts = texts;
    }

    protected abstract String getOpenBBCodeTag();

    protected abstract String getCloseBBCodeTag();

    protected abstract String getMarkdownTag();

    public void toBBCode(StringBuilder stringBuilder) {
        stringBuilder.append(getOpenBBCodeTag());
        for (BBCodeable text : texts) {
            if (text.getClass() == Paragraph.class) {
                throw new UnsupportedOperationException("Paragraph in other paragraph");
            }
            text.toBBCode(stringBuilder);
        }
        stringBuilder.append(getCloseBBCodeTag());
    }

    public void toMarkdown(StringBuilder stringBuilder) {
        stringBuilder.append(getMarkdownTag());
        for (Markdownable text : texts) {
            if (text.getClass() == Paragraph.class) {
                throw new UnsupportedOperationException("Paragraph in other paragraph");
            }
            text.toMarkdown(stringBuilder);
        }
        stringBuilder.append(getMarkdownTag());
    }
}
