package queue;

import java.util.List;
import java.util.function.Function;

public abstract class AbstractQueue implements Queue {

    protected int size;

    @Override
    public abstract void enqueue(Object element);

    public abstract void removeElement();

    @Override
    public Object dequeue() {
        Object result = element();
        size--;
        removeElement();
        return result;
    }

    @Override
    public abstract Object element();

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public void clear() {
        while (!isEmpty()) {
            dequeue();
        }
    }

    @Override
    public Queue removeNth(int n) {
        Queue res = getNth(n);
        dropNth(n);
        return res;
    }

    protected abstract List<Object> get(int n, Function<Pair<Integer, Integer>, Boolean> f);

    public void abstractGetNth(Queue queue, int n) {
        List<Object> nth = get(n, new Function<Pair<Integer, Integer>, Boolean>() {
            @Override
            public Boolean apply(Pair<Integer, Integer> pair) {
                return pair.first % pair.second == 0;
            }
        });
        for (Object element : nth) {
            queue.enqueue(element);
        }
    }

    @Override
    public void dropNth(int n) {
        List<Object> withoutNth = get(n, new Function<Pair<Integer, Integer>, Boolean>() {
            @Override
            public Boolean apply(Pair<Integer, Integer> pair) {
                return pair.first % pair.second > 0;
            }
        });
        clear();
        for (Object element : withoutNth) {
            enqueue(element);
        }
    }
}
