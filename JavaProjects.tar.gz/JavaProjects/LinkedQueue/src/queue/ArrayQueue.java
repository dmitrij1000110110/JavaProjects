package queue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;

public class ArrayQueue extends AbstractQueue {

    private int begin = 0;
    public Object[] elements = new Object[2];

    private void ensureCapacity() {
        if (size == elements.length) {
            elements = Arrays.copyOf(elements, elements.length * 2);
            System.arraycopy(elements, 0, elements, elements.length / 2, begin);
            if (begin > 0) {
                Arrays.fill(elements, 0, begin - 1, null);
            }
        }
    }

    @Override
    public void enqueue(Object element) {
        ensureCapacity();
        elements[(begin + size) % elements.length] = element;
        size++;
    }

    @Override
    public void removeElement() {
        elements[begin++] = null;
    }

    @Override
    public Object dequeue() {
        Object res = elements[begin];
        elements[begin] = null;
        begin = (begin + 1) % elements.length;
        size--;
        return res;
    }

    @Override
    public Object element() {
        return elements[begin];
    }

    @Override
    public Queue getNth(int n) {
        ArrayQueue queue = new ArrayQueue();
        abstractGetNth(queue, n);
        return queue;
    }

    protected List<Object> get(int n, Function<Pair<Integer, Integer>, Boolean> f) {
        List<Object> res = new ArrayList<>();
        for (int i = 1; i <= size; i++) {
            if (f.apply(new Pair(i, n))) {
                res.add(elements[(begin + i - 1) % elements.length]);
            }
        }
        return res;
    }

}
