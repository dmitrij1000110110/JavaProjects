package queue;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class LinkedQueue extends AbstractQueue {

    private static class Node {

        public Node next;
        public Object value;

        Node(Node next, Object value) {
            this.next = next;
            this.value = value;
        }

    }

    private Node head = null;
    private Node tail = null;

    @Override
    public void enqueue(Object element) {
        Node newNode = new Node(null, element);
        if (head == null) {
            head = newNode;
            tail = head;
        } else {
            tail.next = newNode;
            tail = newNode;
        }
        size++;
    }

    @Override
    public void removeElement() {
        head = head.next;
    }

    @Override
    public Object element() {
        return head.value;
    }

    @Override
    public Queue getNth(int n) {
        LinkedQueue queue = new LinkedQueue();
        abstractGetNth(queue, n);
        return queue;
    }

    protected List<Object> get(int n, Function<Pair<Integer, Integer>, Boolean> f) {
        List<Object> res = new ArrayList<>();
        Node current = head;
        for (int i = 1; i <= size; i++) {
            if (f.apply(new Pair(i, n))) {
                res.add(current.value);
            }
            current = current.next;
        }
        return res;
    }
}
